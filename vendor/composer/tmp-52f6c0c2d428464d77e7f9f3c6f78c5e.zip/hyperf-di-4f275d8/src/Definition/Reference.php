<?php

declare(strict_types=1);
/**
 * This file is part of Hyperf.
 *
 * @link     https://www.hyperf.io
 * @document https://hyperf.wiki
 * @contact  group@hyperf.io
 * @license  https://github.com/hyperf/hyperf/blob/master/LICENSE
 */

namespace Hyperf\Di\Definition;

use Psr\Container\ContainerInterface;
use Stringable;

class Reference implements Stringable, DefinitionInterface, SelfResolvingDefinitionInterface
{
    /**
     * Entry name.
     */
    private string $name = '';

    private bool $needProxy = false;

    /**
     * @param string $targetEntryName name of the target entry
     */
    public function __construct(private string $targetEntryName)
    {
    }

    /**
     * Definitions can be cast to string for debugging information.
     */
    public function __toString(): string
    {
        return sprintf('get(%s)', $this->targetEntryName);
    }

    /**
     * Returns the name of the entry in the container.
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Set the name of the entry in the container.
     */
    public function setName(string $name)
    {
        $this->name = $name;
    }

    public function getTargetEntryName(): string
    {
        return $this->targetEntryName;
    }

    public function resolve(ContainerInterface $container)
    {
        return $container->get($this->getTargetEntryName());
    }

    public function isResolvable(ContainerInterface $container): bool
    {
        return $container->has($this->getTargetEntryName());
    }

    /**
     * Determine if the definition need to transfer to a proxy class.
     */
    public function isNeedProxy(): bool
    {
        return $this->needProxy;
    }

    public function setNeedProxy($needProxy): self
    {
        $this->needProxy = $needProxy;
        return $this;
    }
}
