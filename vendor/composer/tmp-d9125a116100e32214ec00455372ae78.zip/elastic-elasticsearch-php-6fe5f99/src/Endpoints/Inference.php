<?php

/**
 * Elasticsearch PHP Client
 *
 * @link      https://github.com/elastic/elasticsearch-php
 * @copyright Copyright (c) Elasticsearch B.V (https://www.elastic.co)
 * @license   https://opensource.org/licenses/MIT MIT License
 *
 * Licensed to Elasticsearch B.V under one or more agreements.
 * Elasticsearch B.V licenses this file to you under the MIT License.
 * See the LICENSE file in the project root for more information.
 */

declare(strict_types=1);

namespace Elastic\Elasticsearch\Endpoints;

use Elastic\Elasticsearch\Exception\ClientResponseException;
use Elastic\Elasticsearch\Exception\MissingParameterException;
use Elastic\Elasticsearch\Exception\ServerResponseException;
use Elastic\Elasticsearch\Response\Elasticsearch;
use Elastic\Transport\Exception\NoNodeAvailableException;
use Http\Promise\Promise;

/**
 * @generated This file is generated, please do not edit
 */
class Inference extends AbstractEndpoint
{
	/**
	 * Perform chat completion inference
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-unified-inference
	 * @group serverless
	 *
	 * @param array{
	 *     inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference request to complete. (DEFAULT: 120s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference payload. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function chatCompletionUnified(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['inference_id','body'], $params);
		$url = '/_inference/chat_completion/' . $this->encode($params['inference_id']) . '/_stream';
		$method = 'POST';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'text/event-stream',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['inference_id'], $request, 'inference.chat_completion_unified');
		return $this->client->sendRequest($request);
	}


	/**
	 * Perform completion inference on the service
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-inference
	 * @group serverless
	 *
	 * @param array{
	 *     inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference request to complete. (DEFAULT: 120s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference payload. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function completion(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['inference_id','body'], $params);
		$url = '/_inference/completion/' . $this->encode($params['inference_id']);
		$method = 'POST';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['inference_id'], $request, 'inference.completion');
		return $this->client->sendRequest($request);
	}


	/**
	 * Delete an inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-delete
	 * @group serverless
	 *
	 * @param array{
	 *     inference_id: string, // (REQUIRED) The inference Id
	 *     task_type?: string, // The task type
	 *     dry_run?: bool, // When true, checks the semantic_text fields and inference processors that reference the endpoint and returns them in a list, but does not delete the endpoint.
	 *     force?: bool, // When true, the inference endpoint is forcefully deleted even if it is still being used by ingest processors or semantic text fields.
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function delete(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['inference_id'], $params);
		if (isset($params['task_type'])) {
			$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['inference_id']);
			$method = 'DELETE';
		} else {
			$url = '/_inference/' . $this->encode($params['inference_id']);
			$method = 'DELETE';
		}
		$url = $this->addQueryString($url, $params, ['dry_run','force','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['inference_id', 'task_type'], $request, 'inference.delete');
		return $this->client->sendRequest($request);
	}


	/**
	 * Delete the inference region policy
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-delete-region-policy
	 * @group serverless
	 *
	 * @param array{
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 * } $params
	 *
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function deleteRegionPolicy(?array $params = null)
	{
		$params = $params ?? [];
		$url = '/_inference/_region_policy';
		$method = 'DELETE';

		$url = $this->addQueryString($url, $params, ['pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, [], $request, 'inference.delete_region_policy');
		return $this->client->sendRequest($request);
	}


	/**
	 * Perform embedding inference on the service
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-embedding
	 * @group serverless
	 * @internal This API is EXPERIMENTAL and may be changed or removed completely in a future release
	 *
	 * @param array{
	 *     inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference request to complete. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference payload. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function embedding(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['inference_id','body'], $params);
		$url = '/_inference/embedding/' . $this->encode($params['inference_id']);
		$method = 'POST';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['inference_id'], $request, 'inference.embedding');
		return $this->client->sendRequest($request);
	}


	/**
	 * Get an inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-get
	 * @group serverless
	 *
	 * @param array{
	 *     inference_id?: string, // The inference Id
	 *     task_type?: string, // The task type
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 * } $params
	 *
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function get(?array $params = null)
	{
		$params = $params ?? [];
		if (isset($params['task_type']) && isset($params['inference_id'])) {
			$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['inference_id']);
			$method = 'GET';
		} elseif (isset($params['inference_id'])) {
			$url = '/_inference/' . $this->encode($params['inference_id']);
			$method = 'GET';
		} else {
			$url = '/_inference';
			$method = 'GET';
		}
		$url = $this->addQueryString($url, $params, ['pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['inference_id', 'task_type'], $request, 'inference.get');
		return $this->client->sendRequest($request);
	}


	/**
	 * Get the inference region policy
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-get-region-policy
	 * @group serverless
	 *
	 * @param array{
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 * } $params
	 *
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function getRegionPolicy(?array $params = null)
	{
		$params = $params ?? [];
		$url = '/_inference/_region_policy';
		$method = 'GET';

		$url = $this->addQueryString($url, $params, ['pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, [], $request, 'inference.get_region_policy');
		return $this->client->sendRequest($request);
	}


	/**
	 * Perform inference on the service
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-inference
	 * @group serverless
	 *
	 * @param array{
	 *     inference_id: string, // (REQUIRED) The inference Id
	 *     task_type?: string, // The task type
	 *     timeout?: int|string, // The amount of time to wait for the inference request to complete. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference payload. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function inference(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['inference_id','body'], $params);
		if (isset($params['task_type'])) {
			$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['inference_id']);
			$method = 'POST';
		} else {
			$url = '/_inference/' . $this->encode($params['inference_id']);
			$method = 'POST';
		}
		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['inference_id', 'task_type'], $request, 'inference.inference');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put
	 * @group serverless
	 *
	 * @param array{
	 *     inference_id: string, // (REQUIRED) The inference Id
	 *     task_type?: string, // The task type
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. The default depends on the task type: 120s for `completion` and `chat_completion`, and 30s for all other task types. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function put(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['inference_id','body'], $params);
		if (isset($params['task_type'])) {
			$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['inference_id']);
			$method = 'PUT';
		} else {
			$url = '/_inference/' . $this->encode($params['inference_id']);
			$method = 'PUT';
		}
		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['inference_id', 'task_type'], $request, 'inference.put');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create a AI21 inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-ai21
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     ai21_inference_id: string, // (REQUIRED) The inference ID
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putAi21(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','ai21_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['ai21_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'ai21_inference_id'], $request, 'inference.put_ai21');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an AlibabaCloud AI Search inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-alibabacloud
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     alibabacloud_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putAlibabacloud(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','alibabacloud_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['alibabacloud_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'alibabacloud_inference_id'], $request, 'inference.put_alibabacloud');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an Amazon Bedrock inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-amazonbedrock
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     amazonbedrock_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putAmazonbedrock(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','amazonbedrock_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['amazonbedrock_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'amazonbedrock_inference_id'], $request, 'inference.put_amazonbedrock');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an Amazon SageMaker inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-amazonsagemaker
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     amazonsagemaker_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putAmazonsagemaker(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','amazonsagemaker_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['amazonsagemaker_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'amazonsagemaker_inference_id'], $request, 'inference.put_amazonsagemaker');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an Anthropic inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-anthropic
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     anthropic_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putAnthropic(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','anthropic_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['anthropic_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'anthropic_inference_id'], $request, 'inference.put_anthropic');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an Azure AI studio inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-azureaistudio
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     azureaistudio_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putAzureaistudio(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','azureaistudio_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['azureaistudio_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'azureaistudio_inference_id'], $request, 'inference.put_azureaistudio');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an Azure OpenAI inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-azureopenai
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     azureopenai_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putAzureopenai(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','azureopenai_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['azureopenai_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'azureopenai_inference_id'], $request, 'inference.put_azureopenai');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create a Cohere inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-cohere
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     cohere_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putCohere(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','cohere_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['cohere_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'cohere_inference_id'], $request, 'inference.put_cohere');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an Contextual AI inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-contextualai
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     contextualai_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putContextualai(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','contextualai_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['contextualai_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'contextualai_inference_id'], $request, 'inference.put_contextualai');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create a custom inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-custom
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     custom_inference_id: string, // (REQUIRED) The inference Id
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putCustom(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','custom_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['custom_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'custom_inference_id'], $request, 'inference.put_custom');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create a DeepSeek inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-deepseek
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     deepseek_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putDeepseek(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','deepseek_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['deepseek_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'deepseek_inference_id'], $request, 'inference.put_deepseek');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an Elasticsearch inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-elasticsearch
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     elasticsearch_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putElasticsearch(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','elasticsearch_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['elasticsearch_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'elasticsearch_inference_id'], $request, 'inference.put_elasticsearch');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an ELSER inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-elser
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     elser_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putElser(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','elser_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['elser_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'elser_inference_id'], $request, 'inference.put_elser');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create a Fireworks AI inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-fireworksai
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     fireworksai_inference_id: string, // (REQUIRED) The inference ID
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putFireworksai(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','fireworksai_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['fireworksai_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'fireworksai_inference_id'], $request, 'inference.put_fireworksai');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an Google AI Studio inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-googleaistudio
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     googleaistudio_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putGoogleaistudio(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','googleaistudio_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['googleaistudio_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'googleaistudio_inference_id'], $request, 'inference.put_googleaistudio');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create a Google Vertex AI inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-googlevertexai
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     googlevertexai_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putGooglevertexai(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','googlevertexai_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['googlevertexai_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'googlevertexai_inference_id'], $request, 'inference.put_googlevertexai');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create a Groq inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-groq
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     groq_inference_id: string, // (REQUIRED) The inference ID
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putGroq(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','groq_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['groq_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'groq_inference_id'], $request, 'inference.put_groq');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create a Hugging Face inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-hugging-face
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     huggingface_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putHuggingFace(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','huggingface_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['huggingface_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'huggingface_inference_id'], $request, 'inference.put_hugging_face');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an JinaAI inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-jinaai
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     jinaai_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putJinaai(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','jinaai_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['jinaai_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'jinaai_inference_id'], $request, 'inference.put_jinaai');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create a Llama inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-llama
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     llama_inference_id: string, // (REQUIRED) The inference ID
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putLlama(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','llama_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['llama_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'llama_inference_id'], $request, 'inference.put_llama');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create a Mistral inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-mistral
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     mistral_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putMistral(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','mistral_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['mistral_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'mistral_inference_id'], $request, 'inference.put_mistral');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an NVIDIA inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-nvidia
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     nvidia_inference_id: string, // (REQUIRED) The inference ID
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putNvidia(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','nvidia_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['nvidia_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'nvidia_inference_id'], $request, 'inference.put_nvidia');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an OpenAI inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-openai
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     openai_inference_id: string, // (REQUIRED) The inference ID
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putOpenai(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','openai_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['openai_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'openai_inference_id'], $request, 'inference.put_openai');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create an OpenShift AI inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-openshift-ai
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     openshiftai_inference_id: string, // (REQUIRED) The inference ID
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putOpenshiftAi(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','openshiftai_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['openshiftai_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'openshiftai_inference_id'], $request, 'inference.put_openshift_ai');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create or update the inference region policy
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-region-policy
	 * @group serverless
	 *
	 * @param array{
	 *     force?: bool, // If `true`, the region policy is applied even if it would deny access to inference endpoints that are currently in use by ingest pipeline or indices.
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The region policy configuration. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putRegionPolicy(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['body'], $params);
		$url = '/_inference/_region_policy';
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['force','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, [], $request, 'inference.put_region_policy');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create a VoyageAI inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-voyageai
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     voyageai_inference_id: string, // (REQUIRED) The inference ID
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putVoyageai(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','voyageai_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['voyageai_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'voyageai_inference_id'], $request, 'inference.put_voyageai');
		return $this->client->sendRequest($request);
	}


	/**
	 * Create a Watsonx inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-put-watsonx
	 * @group serverless
	 *
	 * @param array{
	 *     task_type: string, // (REQUIRED) The task type
	 *     watsonx_inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be created. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function putWatsonx(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['task_type','watsonx_inference_id','body'], $params);
		$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['watsonx_inference_id']);
		$method = 'PUT';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['task_type', 'watsonx_inference_id'], $request, 'inference.put_watsonx');
		return $this->client->sendRequest($request);
	}


	/**
	 * Perform reranking inference on the service
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-inference
	 * @group serverless
	 *
	 * @param array{
	 *     inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // The amount of time to wait for the inference request to complete. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference payload. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function rerank(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['inference_id','body'], $params);
		$url = '/_inference/rerank/' . $this->encode($params['inference_id']);
		$method = 'POST';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['inference_id'], $request, 'inference.rerank');
		return $this->client->sendRequest($request);
	}


	/**
	 * Perform sparse embedding inference on the service
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-inference
	 * @group serverless
	 *
	 * @param array{
	 *     inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference request to complete. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference payload. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function sparseEmbedding(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['inference_id','body'], $params);
		$url = '/_inference/sparse_embedding/' . $this->encode($params['inference_id']);
		$method = 'POST';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['inference_id'], $request, 'inference.sparse_embedding');
		return $this->client->sendRequest($request);
	}


	/**
	 * Perform streaming inference
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-stream-inference
	 * @group serverless
	 *
	 * @param array{
	 *     inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // The amount of time to wait for the inference request to complete. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference payload. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function streamCompletion(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['inference_id','body'], $params);
		$url = '/_inference/completion/' . $this->encode($params['inference_id']) . '/_stream';
		$method = 'POST';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'text/event-stream',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['inference_id'], $request, 'inference.stream_completion');
		return $this->client->sendRequest($request);
	}


	/**
	 * Perform text embedding inference on the service
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-inference
	 * @group serverless
	 *
	 * @param array{
	 *     inference_id: string, // (REQUIRED) The inference Id
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference request to complete. (DEFAULT: 30s)
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference payload. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function textEmbedding(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['inference_id','body'], $params);
		$url = '/_inference/text_embedding/' . $this->encode($params['inference_id']);
		$method = 'POST';

		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['inference_id'], $request, 'inference.text_embedding');
		return $this->client->sendRequest($request);
	}


	/**
	 * Update an inference endpoint
	 *
	 * @link https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-inference-update
	 * @group serverless
	 *
	 * @param array{
	 *     inference_id: string, // (REQUIRED) The inference Id
	 *     task_type?: string, // The task type
	 *     timeout?: int|string, // Specifies the amount of time to wait for the inference endpoint to be updated. The default depends on the task type: 120s for `completion` and `chat_completion`, and 30s for all other task types.
	 *     pretty?: bool, // Pretty format the returned JSON response. (DEFAULT: false)
	 *     human?: bool, // Return human readable values for statistics. (DEFAULT: true)
	 *     error_trace?: bool, // Include the stack trace of returned errors. (DEFAULT: false)
	 *     source?: string, // The URL-encoded request definition. Useful for libraries that do not accept a request body for non-POST requests.
	 *     filter_path?: string|array<string>, // A comma-separated list of filters used to reduce the response.
	 *     body: string|array<mixed>, // (REQUIRED) The inference endpoint's task and service settings. If body is a string must be a valid JSON.
	 * } $params
	 *
	 * @throws MissingParameterException if a required parameter is missing
	 * @throws NoNodeAvailableException if all the hosts are offline
	 * @throws ClientResponseException if the status code of response is 4xx
	 * @throws ServerResponseException if the status code of response is 5xx
	 *
	 * @return Elasticsearch|Promise
	 */
	public function update(?array $params = null)
	{
		$params = $params ?? [];
		$this->checkRequiredParameters(['inference_id','body'], $params);
		if (isset($params['task_type'])) {
			$url = '/_inference/' . $this->encode($params['task_type']) . '/' . $this->encode($params['inference_id']) . '/_update';
			$method = 'PUT';
		} else {
			$url = '/_inference/' . $this->encode($params['inference_id']) . '/_update';
			$method = 'PUT';
		}
		$url = $this->addQueryString($url, $params, ['timeout','pretty','human','error_trace','source','filter_path']);
		$headers = [
			'Accept' => 'application/json',
			'Content-Type' => 'application/json',
		];
		$request = $this->createRequest($method, $url, $headers, $params['body'] ?? null);
		$request = $this->addOtelAttributes($params, ['inference_id', 'task_type'], $request, 'inference.update');
		return $this->client->sendRequest($request);
	}
}
