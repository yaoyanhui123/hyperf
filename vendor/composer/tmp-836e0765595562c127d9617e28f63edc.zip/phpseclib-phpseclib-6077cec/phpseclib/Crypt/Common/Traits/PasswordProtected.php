<?php

/**
 * Password Protected Trait for Private Keys
 *
 * PHP version 8.1+
 *
 * @author    Jim Wigginton <terrafrost@php.net>
 * @copyright 2019-2026 Jim Wigginton
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      https://phpseclib.com/
 */

declare(strict_types=1);

namespace phpseclib4\Crypt\Common\Traits;

/**
 * Password Protected Trait for Private Keys
 *
 * @author  Jim Wigginton <terrafrost@php.net>
 */
trait PasswordProtected
{
    protected ?string $password = null;

    /**
     * Sets the password
     *
     * Private keys can be encrypted with a password.  To unset the password, pass in the empty string or null.
     * Or rather, pass in $password such that empty($password) && !is_string($password) is true.
     *
     * @see self::createKey()
     * @see self::load()
     *
     * @return static
     */
    public function withPassword(#[\SensitiveParameter] ?string $password = null): self
    {
        $new = clone $this;
        $new->password = $password;
        return $new;
    }

    public function withoutPassword(): self
    {
        return $this->withPassword();
    }

    public function hasPassword(): bool
    {
        return isset($this->password);
    }
}
