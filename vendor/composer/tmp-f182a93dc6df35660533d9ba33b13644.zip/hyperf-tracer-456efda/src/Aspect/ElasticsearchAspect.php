<?php

declare(strict_types=1);
/**
 * This file is part of Hyperf.
 *
 * @link     https://www.hyperf.io
 * @document https://hyperf.wiki
 * @contact  group@hyperf.io
 * @license  https://github.com/hyperf/hyperf/blob/master/LICENSE
 */

namespace Hyperf\Tracer\Aspect;

use Hyperf\Di\Aop\AbstractAspect;
use Hyperf\Di\Aop\ProceedingJoinPoint;
use Hyperf\Tracer\SpanStarter;
use Hyperf\Tracer\SpanTagManager;
use Hyperf\Tracer\SwitchManager;
use Throwable;

class ElasticsearchAspect extends AbstractAspect
{
    use SpanStarter;

    public array $classes = [
        'Elasticsearch\Client::bulk',
        'Elasticsearch\Client::count',
        'Elasticsearch\Client::create',
        'Elasticsearch\Client::get',
        'Elasticsearch\Client::getSource',
        'Elasticsearch\Client::index',
        'Elasticsearch\Client::mget',
        'Elasticsearch\Client::msearch',
        'Elasticsearch\Client::scroll',
        'Elasticsearch\Client::search',
        'Elasticsearch\Client::update',
        'Elasticsearch\Client::updateByQuery',
        'Elasticsearch\Client::search',
        // 8.x
        'Elastic\Elasticsearch\Traits\ClientEndpointsTrait::bulk',
        'Elastic\Elasticsearch\Traits\ClientEndpointsTrait::count',
        'Elastic\Elasticsearch\Traits\ClientEndpointsTrait::create',
        'Elastic\Elasticsearch\Traits\ClientEndpointsTrait::get',
        'Elastic\Elasticsearch\Traits\ClientEndpointsTrait::getSource',
        'Elastic\Elasticsearch\Traits\ClientEndpointsTrait::index',
        'Elastic\Elasticsearch\Traits\ClientEndpointsTrait::mget',
        'Elastic\Elasticsearch\Traits\ClientEndpointsTrait::msearch',
        'Elastic\Elasticsearch\Traits\ClientEndpointsTrait::scroll',
        'Elastic\Elasticsearch\Traits\ClientEndpointsTrait::search',
        'Elastic\Elasticsearch\Traits\ClientEndpointsTrait::update',
        'Elastic\Elasticsearch\Traits\ClientEndpointsTrait::updateByQuery',
        'Elastic\Elasticsearch\Traits\ClientEndpointsTrait::search',
    ];

    public function __construct(private SwitchManager $switchManager, private SpanTagManager $spanTagManager)
    {
    }

    /**
     * @return mixed return the value from process method of ProceedingJoinPoint, or the value that you handled
     */
    public function process(ProceedingJoinPoint $proceedingJoinPoint)
    {
        if ($this->switchManager->isEnable('elasticserach') === false) {
            return $proceedingJoinPoint->process();
        }

        $key = $proceedingJoinPoint->className . '::' . $proceedingJoinPoint->methodName;
        $span = $this->startSpan($key);
        try {
            $result = $proceedingJoinPoint->process();
        } catch (Throwable $e) {
            if ($this->switchManager->isEnable('exception') && ! $this->switchManager->isIgnoreException($e)) {
                $span->setTag('error', true);
                $span->log(['message', $e->getMessage(), 'code' => $e->getCode(), 'stacktrace' => $e->getTraceAsString()]);
            }
            throw $e;
        } finally {
            $span->finish();
        }
        return $result;
    }
}
