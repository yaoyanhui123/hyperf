<?php

declare(strict_types=1);
/**
 * This file is part of Hyperf.
 *
 * @link     https://www.hyperf.io
 * @document https://hyperf.wiki
 * @contact  group@hyperf.io
 * @license  https://github.com/hyperf/hyperf/blob/master/LICENSE
 */

namespace Hyperf\Redis;

use Hyperf\Context\Context;
use Hyperf\Redis\Exception\InvalidRedisConnectionException;
use Hyperf\Redis\Pool\PoolFactory;
use Throwable;

use function Hyperf\Coroutine\defer;

/**
 * @mixin \Redis
 */
class Redis
{
    use Traits\ScanCaller;
    use Traits\MultiExec;

    protected string $poolName = 'default';

    public function __construct(protected PoolFactory $factory)
    {
    }

    public function __call(string $name, array $arguments): mixed
    {
        // Get a connection from coroutine context or connection pool.
        $hasContextConnection = Context::has($this->getContextKey());
        $connection = $this->getConnection($hasContextConnection);
        // Record the start time of the command.
        $start = (float) microtime(true);

        try {
            /** @var RedisConnection $connection */
            $connection = $connection->getConnection();
            // Execute the command with the arguments.
            $result = $connection->{$name}(...$arguments);
        } catch (Throwable $exception) {
            throw $exception;
        } finally {
            $time = round((microtime(true) - $start) * 1000, 2);
            // Dispatch the command executed event.
            $connection->getEventDispatcher()?->dispatch(
                new Event\CommandExecuted(
                    $name,
                    $arguments,
                    $time,
                    $connection,
                    $this->poolName,
                    $result ?? null,
                    $exception ?? null,
                )
            );

            // Release connection.
            if (! $hasContextConnection) {
                if ($this->shouldUseSameConnection($name)) {
                    if ($name === 'select' && $db = $arguments[0]) {
                        $connection->setDatabase((int) $db);
                    }
                    // Should storage the connection to coroutine context, then use defer() to release the connection.
                    Context::set($this->getContextKey(), $connection);
                    if (! $this->isInEagerReleaseMode()) {
                        defer(function () {
                            $this->releaseContextConnection();
                        });
                    }
                } else {
                    // Release the connection after command executed.
                    $connection->release();
                }
            }
        }

        return $result;
    }

    /**
     * Release the connection stored in coroutine context.
     */
    private function releaseContextConnection(): void
    {
        $contextKey = $this->getContextKey();
        $connection = Context::get($contextKey);

        if ($connection) {
            Context::set($contextKey, null);
            $connection->release();
        }
    }

    /**
     * Define the commands that need same connection to execute.
     * When these commands executed, the connection will storage to coroutine context.
     */
    private function shouldUseSameConnection(string $methodName): bool
    {
        return in_array($methodName, [
            'multi',
            'pipeline',
            'select',
        ]);
    }

    /**
     * Get a connection from coroutine context, or from redis connection pool.
     * @param mixed $hasContextConnection
     */
    private function getConnection($hasContextConnection): RedisConnection
    {
        $connection = null;
        if ($hasContextConnection) {
            $connection = Context::get($this->getContextKey());
        }
        if (! $connection instanceof RedisConnection) {
            $pool = $this->factory->getPool($this->poolName);
            $connection = $pool->get();
        }
        if (! $connection instanceof RedisConnection) {
            throw new InvalidRedisConnectionException('The connection is not a valid RedisConnection.');
        }
        return $connection;
    }

    /**
     * The key to identify the connection object in coroutine context.
     */
    private function getContextKey(): string
    {
        return sprintf('redis.connection.%s', $this->poolName);
    }

    /**
     * Whether the connection should be released immediately after exec(),
     * instead of deferring until the coroutine ends.
     */
    private function isInEagerReleaseMode(): bool
    {
        return (bool) Context::get($this->getEagerReleaseContextKey());
    }

    /**
     * Mark that the connection should be released immediately after exec().
     */
    private function enterEagerReleaseMode(): void
    {
        Context::set($this->getEagerReleaseContextKey(), true);
    }

    /**
     * Clear the eager-release mark.
     */
    private function exitEagerReleaseMode(): void
    {
        Context::destroy($this->getEagerReleaseContextKey());
    }

    private function getEagerReleaseContextKey(): string
    {
        return sprintf('redis.connection.%s.eager_release', $this->poolName);
    }
}
