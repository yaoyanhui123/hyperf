<?php

declare(strict_types=1);

namespace Swoole\Coroutine;

/**
 * A channel for communication between coroutines, similar to channels in the Go programming language.
 *
 * A channel is a fixed-capacity, first-in-first-out queue that coroutines use to pass values to each other: one
 * coroutine pushes values in, another pops them out. When the channel is full, push() suspends the current
 * coroutine until room becomes available; when it's empty, pop() suspends the current coroutine until a value
 * arrives. This makes channels the primary building block for producer-consumer patterns, connection pools, and
 * other coordination between coroutines. Channels only work between coroutines within the same process; they cannot
 * be used across processes.
 *
 * @template TData
 * @not-serializable Objects of this class cannot be serialized.
 * @alias This class has two aliases: \chan and \Co\Channel (when directive "swoole.use_shortname" is not explicitly turned off).
 * @see \chan
 * @see \Co\Channel
 */
class Channel
{
    /**
     * Size of the channel. This indicates the maximum number of elements that can be stored in the channel. It has to be greater than 0.
     */
    public int $capacity = 0;

    /**
     * Error code of the last push() or pop() operation.
     *
     * When no errors occur during a call to method push() or pop(), the value is 0 (SWOOLE_CHANNEL_OK).
     * When some error occurs during a call to method push() or pop(), the call returns FALSE, and $this->errCode is set
     * to one of the following values: SWOOLE_CHANNEL_TIMEOUT, SWOOLE_CHANNEL_CLOSED, or SWOOLE_CHANNEL_CANCELED.
     *
     * @see SWOOLE_CHANNEL_OK
     * @see SWOOLE_CHANNEL_TIMEOUT
     * @see SWOOLE_CHANNEL_CLOSED
     * @see SWOOLE_CHANNEL_CANCELED
     */
    public int $errCode = SWOOLE_CHANNEL_OK;

    /**
     * Create a new channel of the given capacity.
     *
     * The channel is stored in memory local to the current process, which is why channels only work between
     * coroutines within the same process.
     *
     * @param int $size Size of the channel. This indicates the maximum number of elements that can be stored in the channel. It has to be greater than 0.
     * @pseudocode-included This is a built-in method in Swoole. The PHP code included inside this method is for explanation purpose only.
     */
    public function __construct(int $size = 1)
    {
        // Here are some statements to create the channel using local memory within the process.

        $this->capacity = max(1, $size);
    }

    /**
     * Push an element into the channel.
     *
     * @param TData $data The element to be pushed into the channel. It's allowed to be any type of value. However, to avoid any confusion, it's recommended not to use empty values like 0, 0.0, false, ' ', null, etc.
     * @param float $timeout Maximum time to wait (in seconds) when the channel is full. If it's 0, a negative number
     *                       (which is the default), or any other value not greater than 0, the call waits indefinitely
     *                       until room becomes available in the channel.
     * @return bool TRUE on success. If failed, return FALSE and set the error code ($this->errCode) with a non-zero value.
     */
    public function push(mixed $data, float $timeout = -1): bool
    {
    }

    /**
     * Pop an element from the channel.
     *
     * This pop operation works in a FIFO (first-in-first-out) manner, since elements in the channel are stored in a queue but not a stack.
     *
     * @param float $timeout Maximum time to wait (in seconds) when the channel is empty. If it's 0, a negative number
     *                       (which is the default), or any other value not greater than 0, the call waits indefinitely
     *                       until an element is pushed into the channel.
     * @return TData|false Remove an element from the front end of the channel, and return the element back. If failed, return FALSE and set the error code ($this->errCode) with a non-zero value.
     */
    public function pop(float $timeout = -1): mixed
    {
    }

    /**
     * Check if the channel is empty, i.e., whether a pop() call would have to wait for an element to arrive.
     *
     * @return bool Returns true if the channel is empty, false otherwise.
     * @see \Swoole\Coroutine\Channel::pop()
     */
    public function isEmpty(): bool
    {
    }

    /**
     * Check if the channel is full (the number of queued elements has reached the channel capacity), i.e., whether a
     * push() call would have to wait for room to become available.
     *
     * @return bool Returns true if the channel is full, false otherwise.
     * @see \Swoole\Coroutine\Channel::push()
     */
    public function isFull(): bool
    {
    }

    /**
     * Close the channel.
     *
     * After the channel is closed,
     *   1. no more elements can be pushed into it: calls to method push() return FALSE right away.
     *   2. elements already in the channel can still be popped out of it, until the channel is empty; after that,
     *      calls to method pop() return FALSE right away.
     *   3. coroutines that are waiting in method push() for room to become available are woken up; inside those
     *      coroutines, the calls to method push() return FALSE.
     *   4. coroutines that are waiting in method pop() for an element to arrive are woken up; inside those coroutines,
     *      the calls to method pop() return FALSE (the channel is empty, since they were waiting).
     *
     * In all these cases, property $errCode is set to SWOOLE_CHANNEL_CLOSED.
     *
     * @return bool Returns TRUE on success, or FALSE if the channel is closed already.
     */
    public function close(): bool
    {
    }

    /**
     * Returns stats of the channel.
     *
     * The array returned contains three fields:
     *   1. consumer_num: Number of calls to method `pop()` that are waiting for elements to be pushed into the channel. This happens when the channel is empty.
     *   2. producer_num: Number of calls to method `push()` that are waiting for elements to be popped from the channel. This happens when the channel is full.
     *   3. queue_num: Number of elements in the channel. This is the same as the return value of statement `self::length()`.
     *
     * The returned array looks like this, e.g.,
     * ```php
     * [
     *     'consumer_num' => 0, // No calls to method `pop()` in waiting at the moment.
     *     'producer_num' => 1, // The channel is full, and there is one method call to method `push()` that is waiting for elements to be popped from the channel.
     *     'queue_num'    => 2, // There are two elements in the channel. In this case, the size of the channel is also two.
     * ]
     * ```
     *
     * @return array Returns an array with three fields in it: "consumer_num", "producer_num", and "queue_num".
     */
    public function stats(): array
    {
    }

    /**
     * Get the number of elements currently queued in the channel.
     *
     * @return int Number of elements in the channel.
     */
    public function length(): int
    {
    }
}
